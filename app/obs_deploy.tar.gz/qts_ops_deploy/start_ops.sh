#!/bin/bash

# QTS Observer Startup Script
echo "Starting QTS Observer in /app structure..."

# Set environment variables
export QTS_OBSERVER_STANDALONE=1
export PYTHONPATH=/app/src:/app
export OBSERVER_DATA_DIR=/app/data/observer
export OBSERVER_LOG_DIR=/app/logs

# Create log symlink for compatibility
mkdir -p /app/data/observer
ln -sf /app/logs /app/data/observer/logs

# Start Observer
cd /app
python observer.py
